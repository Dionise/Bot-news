import telebot
import config
import time
from bs4 import BeautifulSoup
import urllib.request

bot = telebot.TeleBot(config.TOKEN)


class Classs():

    def __init__(self):
        self.bot = bot

    def function(self, message):
        info = urllib.request.urlopen('https://news.yam.md/')
        html = info.read()
        soup = BeautifulSoup(html, 'html.parser')
        new = soup.find_all(class_="news-list-row story-row-container")
        for item in new:
            titlu = item.find(class_="news-row-title").get_text(strip=True)
            ok = self.bot.send_message(message.chat.id, titlu)
            time.sleep(600)
        return ok


@bot.message_handler(content_types=['text'])
def send_text(message):
    while True:
        x = Classs()
        x.function(message)
        time.sleep(1500)


if __name__ == '__main__':
    bot.polling(none_stop=True)
